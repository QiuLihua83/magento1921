<?php

class Chinapay_Chinapay_Block_Error extends Mage_Core_Block_Template
{
}