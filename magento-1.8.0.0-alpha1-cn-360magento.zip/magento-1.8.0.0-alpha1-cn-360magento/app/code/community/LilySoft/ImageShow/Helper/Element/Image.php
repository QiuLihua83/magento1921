<?php
class LilySoft_ImageShow_Helper_Element_Image extends Varien_Data_Form_Element_Image
{
	
}
?>
