<?php
$installer = $this;