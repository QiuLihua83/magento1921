<?php

class LilySoft_Tenpay_Model_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup
{
}
